setwd("C:\\Users\\it24103185\\Desktop\\IT24103185")
dbinom(46,50,0.85,  lower.tail = FALSE)
dpois(15,12)



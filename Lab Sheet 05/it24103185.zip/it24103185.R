setwd("C:\\Users\\it24103185\\Desktop\\IT24103185")
data<-read.table("Data.txt",header=TRUE,sep = ",")
fix(data)
attach(data)

names(data)<-c("X1","X2")
attach(data)
hist(X2,main="Histogran for Number of shareholders")
histogram<-hist(X2,main="Histogram for number of Shareholders",breaks = seq(20,70,length = 9),right = FALSE)

?Hist

breaks <- round(histogram$breacks)
freq <- histogram$counts
mids <- histogram$mids

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i] <- paste0("[",breaks[i], ",",breaks[i+1], ")")
}
cbind(classes = classes, frequency = freq)
lines(mids,freq)

plot(mids,freq,type = "]",main = "frequency polgon for shareholders",xlab = "shareholders",ylab = "frequency", ylim = c(0,max(freq)))
cum.freq <- cumsum(freq)

new<-c()

for(i in 1: length(breaks)){
  if(i == 1){
    new[i] = 0
  }else{
    new[i] = cum.freq[i-1]
  }
}

plot(breaks,new,type = ']', main = "cumalative Frequency polygon for shareholders",xlab = "shareholders", ylab = "cumulative frequency", ylim = c(0,max(cum.freq)))
cbind(Upper = breaks, cumFreq = new)

